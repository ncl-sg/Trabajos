n = int(input("Introduzca n: ")) #se le pide al usuario el numero a evaluar
nbak = n
m = 0
while n > 0 : #se evalua el numero mientra este sea mayor que 0
    r = n % 10 #se saca el residuo de dividirlo por 10 para sacar su ultima cifra
    n = n // 10 #se disminuye el numero al divirlo por cero, quitando asi la ultima cifra
    m = m * 10 + r #se agrega el residuo de antes (la ultima cifra) a la variable m
if nbak == m : #evalua si ambos numeros son iguales
    print(f"SI es un palindromo: {nbak} -> {m}") #imprime si es palindromo
else :
    print(f"NO es un palindromo: {nbak} -> {m}") #imprime si no es palindromo