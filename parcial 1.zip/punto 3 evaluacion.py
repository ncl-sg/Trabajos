n = input("Introduzca n: ") #se le pide al usuario el numero que desea evaluar
ncant = len(n) #se define la cantidad de cifras que tiene el numero n
p = ""
m = ""
for i in range(len(n)) : #se iteran los indices de la cadena de texto n
    d = int(n[i]) #d se define como la cifra la cual esta en el indice i de la cadena de texto n (la cual es el numero dado por el usuario)
    if d % 2 == 0 : #se evalua si la cifra es par
        p = p + " " + str(d)  #si es par, se suma a la variable la cual guarda los valores pares
    else :
        m = m + " " + str(d) #si es impar, se suma a la variable la cual guarda los valores impares
print(f"Las cifras pares son: {p}") #se imprimen las cifras pares
print(f"Las cifras impares son: {m}") #se imprimen las cifras impares
print(f"El numero tiene en total {ncant} cifras") #se imprime la cantidad de cifras del numero n