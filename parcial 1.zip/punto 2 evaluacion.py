while True : #se presenta el menu de operaciones disponibles
    print('''Elija el numero de la oprecion que desea realizar
      las operaciones disponibles son:
      1. determinar si es par o impar
      2. determinar si es primo''')
    o = input("Elija una operacion: ")
    n = int(input("Digite el numero que desea evaluar: "))
    if n >= 0: #si el numero es mayor o igual a 0 se rompe el bucle y continua evaluando
        break
    else : #si el numero es menor que 0 (negativo) entonces el bucle continua y solicita un nuevo numero
        print("El numero no es positivo")
if o == "1" :
    if n % 2 == 0 : #se evalua si el numero es par, al buscar si al dividirlo entre 2 da residuo cero
        print(f"El numero {n} es par") #se imprime si es par
    else :
        print(f"El numero {n} es impar") #se imprime si es impar
elif o == "2" :
    d = 0
    m = 1
    while m <= n: #en el bucle se evalua si n es divisible entre m  y se repite hasta que m=n
        if n % m == 0: 
            d += 1
        m += 1
    if d == 2 : #Se evalua si el numero n tiene igual a 2 divisores, si es asi significa que es primo
        a = n
        print(f"El numero {n} SI es primo") #Se imprime si el numero es primo
    else :
        print(f"El numero {n} NO es primo") #Se imprime si el numero no es primo
else :
    print("Opcion de operacion invalida") #si la opcion de operacion no es ni 1 ni 2 se imprime y se acaba el programa