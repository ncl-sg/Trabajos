#Se importa librerias
import turtle
import random
import pygame as gm
import time
import os

# Inicializar música
gm.mixer.init() #inicia el modulo de sonido
gm.mixer.music.load("assets/music_fondo.mp3") #carga la musica de fondo
gm.mixer.music.play(-1) #se reproduce sin parar

sonido_colision = gm.mixer.Sound("assets/classic_hurt.wav") #se carga el sonido de colision

# Puntuación
puntuacion_jugador = 0
puntuacion = "assets/puntuacion_maxima.txt" #Se le nombra el archivo txt a la variable "puntuación"

def cargar_puntuacion_maxima(): #Función para cargar la puntuación máxima registrada en el archivo
    if os.path.exists(puntuacion): #Si existe el archivo se realiza las acciones
        with open(puntuacion, "r") as file: #Se abre el archivo en modo lectura
            lineas = file.readlines() #Lee todas las lineas del archivo y las devuelve como una lista de cadenas.
            if lineas:
                # La primera línea siempre será la puntuación máxima
                try: #se utiliza try-except para evitar errores al leer el archivo
                    return int(lineas[0].strip()) #Accede a la primera linea de la lista, eliminando cualquier espacio en blanco inicial o final con "strip" y además convierte los valores en enteros.
                except ValueError: #Si falla "int(lineas[0].strip()" se devuelve un 0
                    return 0 
    return 0

def guardar_puntuaciones(puntuacion_actual, nueva_puntuacion_maxima): #Función para guardar la puntuación máxima y las demás conseguidas en el archivo.
    puntuaciones_guardadas = [] #Lista vacia, que guardara todas las puntuaciones leidas del archivo txt más la puntuación actual conseguida.
    if os.path.exists(puntuacion): #Verifica si existe el archivo txt
        with open(puntuacion, "r") as file: #Se abre el archivo en modo lectura
            lineas = file.readlines() #Lee todas las lineas del archivo y las devuelve como una lista de cadenas.
            if len(lineas) > 1: # Si hay más de una línea, significa que hay puntuaciones anteriores
                for line in lineas[1:]: # Ignoramos la primera línea (puntuación máxima)
                    try: #Para manejar ciertos errores al convertir los valores a enteros.
                        puntuaciones_guardadas.append(int(line.strip())) #Añade la puntuación a la lista
                    except ValueError:
                        pass #Se ignoran los imprevistos

    # Añadir la puntuación actual al registro
    puntuaciones_guardadas.append(puntuacion_actual)
    # Ordenar de mayor a menor y tomar solo las mejores
    puntuaciones_guardadas.sort(reverse=True)
    puntuaciones_guardadas = puntuaciones_guardadas[:MAX_PUNTUACIONES_A_MOSTRAR] #Limita la lista, para que solo muestre las puntuaciones más altas según indique la constante.

    with open(puntuacion, "w") as file: #Abre el archivo en modo escritura
        file.write(str(nueva_puntuacion_maxima) + "\n") # Se escribe la nueva puntuación máxima, la convierte en cadena y se añade un salto de página.
        for score in puntuaciones_guardadas:
            file.write(str(score) + "\n") #Escribe estas puntuaciones en una nueva linea en el archivo.

puntuacion_maxima = cargar_puntuacion_maxima() #llama a la función para guardar su información en la variable.
MAX_PUNTUACIONES_A_MOSTRAR = 5 #Esta constante define cuantas puntuaciones se mostraran.

# Pantalla
tiempo_retraso = 0.125
ventana = turtle.Screen()
ventana.title("Laberinto de serpientes") #Titulo de la ventana abierta
ventana.bgcolor("black")
ventana.setup(width=640, height=480) #Se define el tamaño de la ventana
ventana.tracer(0)
ventana.bgpic("assets/background.gif") #Se le añade el fondo al juego con la función ".bgpic"


# Cargar sprites que se usaran
sprites = [
    "assets/snakehead_up.gif", "assets/snakehead_down.gif", "assets/snakehead_left.gif", "assets/snakehead_right.gif",
    "assets/snaketail_up.gif", "assets/snaketail_down.gif", "assets/snaketail_left.gif", "assets/snaketail_right.gif",
    "assets/snakebody.gif", "assets/apple.gif"
]
for sprite in sprites: #se agregan los sprite a la ventana
    ventana.addshape(sprite)

# Serpiente
serpiente = turtle.Turtle() #crea la serpiente
serpiente.shape("assets/snakehead_up.gif") #le asigna el sprite a la serpiente
serpiente.penup() #hace que la serpiente no dibuje lineas al moverse 
serpiente.goto(0, 0) #posiciona la serpiente en el centro
serpiente.direccion = "Stop" #la serpiente no se mueve al inicio

# Comida
comida = turtle.Turtle() #crea el item de comida
comida.shape("assets/apple.gif") # le asigna el sprite a dicho item
comida.penup() #hace que no dibuje lineas al moverse
comida.goto(0, 100) #posiciona el item comida en dicha posicion

# Texto
pluma = turtle.Turtle() #crea el texto
pluma.speed(0) #el valor cambia de forma instantanea
pluma.color("white") #se le asigna el color blanco al texto
pluma.penup() #para que no dibuje lineas al cambiar el texto
pluma.hideturtle() #para ocultar la tortuga del item
pluma.goto(0, 190) #posiciona el texto
pluma.write("Puntuación: 0  Puntuación más alta: 0", align="center", font=("Arial", 24, "normal")) #se describe el texto que se generara


def mostrar_pantalla_carga(): #Función para la pantalla de carga
    fondo_original = ventana.bgpic() #Se guarda el fondo original que tiene el juego.
    color_fondo_original = ventana.bgcolor() #Se guarda también el color original del fondo.

    ventana.bgcolor("black")  #Se define el color de fondo de la pantalla de carga
    ventana.bgpic("assets/snakeGame.gif") #Se añade la pantalla de carga
    
    # Ocultar todos los elementos del juego temporalmente.
    serpiente.hideturtle()
    comida.hideturtle()
    pluma.clear() 
    pluma.hideturtle() 

    ventana.update()
    time.sleep(4) #TIempo que se mostrará la pantalla de carga

    ventana.bgpic(fondo_original) #Después del tiempo transcurrido, se muestra el fondo original del juego
    ventana.bgcolor(color_fondo_original)  #Después del tiempo transcurrido, se muestra el color original del juego

    #Se vuelven a mostrar los elementos del juego nuevamente
    serpiente.showturtle() 
    comida.showturtle()
    pluma.hideturtle()
    pluma.write(f"Puntuación: {puntuacion_jugador}  Puntuación más alta: {puntuacion_maxima}", align="center", font=("Arial", 24, "normal"))
    
    

def mostrar_tabla_final(): #Se define una función para la tabla final de puntuaciones 
    pluma.clear() #Se eliminan los textos que se tienen actualmente
    pluma.goto(0, 150) #Posición del texto
    pluma.write("¡Juego Terminado!", align="center", font=("Arial", 30, "bold")) #Texto
    pluma.goto(0, 100)#Posición del texto
    pluma.write(f"Tu Puntuación: {puntuacion_jugador}", align="center", font=("Arial", 24, "normal")) #Texto
    pluma.goto(0, 60) #Posición del texto
    pluma.write(f"Puntuación Máxima: {puntuacion_maxima}", align="center", font=("Arial", 24, "normal")) #Texto

    pluma.goto(0, 0) #Posición del texto
    pluma.write("--- Tabla de Mejores Puntuaciones ---", align="center", font=("Arial", 20, "underline")) #Texto

    puntuaciones_cargadas = [] #Se inicia lista vacia para almacenar las puntuaciones que se leeran del archivo y se mostraran en la tabla 
    if os.path.exists(puntuacion): #Verifica si el archivo txt existe
        with open(puntuacion, "r") as file: #Se abre el archivo en modo lectura
            lineas = file.readlines() #Lee todas las lineas del archivo
            if len(lineas) > 1: #Se verifica si hay más de una linea en el archivo
                for line in lineas[1:]: #Realiza el cambio del archivo a partir de la segunda linea del archivo, ignorando la primera (puntuación máxima)
                    try:
                        puntuaciones_cargadas.append(int(line.strip())) #Añade el valor convertido en entero a la lista creada antes.
                    except ValueError:
                        pass #Se ignora si llega a ocurrir algún error
    
    #  Se verifica de que la puntuación conseguida no este en las puntuaciones antes conseguidas, evitando duplicados
    if puntuacion_jugador not in puntuaciones_cargadas:
        puntuaciones_cargadas.append(puntuacion_jugador) #Si la posición no era duplicado de otra, se añade.
    
    puntuaciones_cargadas.sort(reverse=True) #Ordena las puntuaciones conseguidas de mayor a menor
    puntuaciones_cargadas = puntuaciones_cargadas[:MAX_PUNTUACIONES_A_MOSTRAR] #Limita la lista en base a lo que la constante tenga.

    y_pos = -40 #Posición usada más adelanta
    for i, score in enumerate(puntuaciones_cargadas): #Bucle para leer todos los valores de la lista
        pluma.goto(0, y_pos)
        pluma.write(f"{i+1}. {score}", align="center", font=("Arial", 18, "normal")) #Escribe cada puntuación leida.
        y_pos -= 30 #Reduce el tamaño de la posición y, haciendo que después de cada puntuación esta baje para evitar colisiones
    
    pluma.goto(0, y_pos - 30)
    pluma.write("Presiona 'R' para Reiniciar", align="center", font=("Arial", 16, "normal")) #Mensaje para indicarle al usuario la tecla que debe presionar para que se reinicie

    # Esperar por la tecla 'R' para reiniciar
    ventana.onkeypress(reiniciar_juego, "r") #Cuando la tecla sea presionada se llamara a la función "reiniciar juego"
    ventana.listen() # Asegurarse de que la ventana escuche la tecla 'r'

def reiniciar_juego(): #Se define la función con la que se reiniciará el juego.
    global puntuacion_jugador, tiempo_retraso, puntuacion_maxima #Se cambian las variables globales 
    pluma.clear()  # Limpiar pantalla de la tabla de puntuaciones
    
    # Resetear el juego
    serpiente.goto(0, 0) #la serpiente es llevada al centro
    serpiente.direction = "Stop" #detiene la serpiente
    serpiente.shape("assets/snakehead_up.gif") #se le asigna el sprite a la serpiente

    for segmento in segmentos: #envia los segmentos a una posicion lejana de la pantalla y los elimina
        segmento.goto(1000, 1000)
    segmentos.clear()

    puntuacion_jugador = 0 #resetea la puntuacion
    tiempo_retraso = 0.125 #resetea la velocidad
    puntuacion_maxima = cargar_puntuacion_maxima() # Volver a cargar la máxima al reiniciar
    
    pluma.clear()
    pluma.hideturtle()
    pluma.goto(0, 190) #Posición
    pluma.write(f"Puntuación: {puntuacion_jugador}  Puntuación más alta: {puntuacion_maxima}", align="center", font=("Arial", 24, "normal")) #Texto
    
    # Reiniciar la música
    gm.mixer.music.play(-1)
    
    # Volver a activar los controles normales del juego
    ventana.onkeypress(ir_arriba, "w")
    ventana.onkeypress(ir_abajo, "s")
    ventana.onkeypress(ir_izquierda, "a")
    ventana.onkeypress(ir_derecha, "d")
    ventana.listen()

    # Reiniciar el bucle del juego
    juego()


# la funcion asigna el sprite correspondiente al movimiento de la serpiente
def actualizar_sprite_cabeza():
    if serpiente.direccion == "arriba":
        serpiente.shape("assets/snakehead_up.gif")
    elif serpiente.direccion == "abajo":
        serpiente.shape("assets/snakehead_down.gif")
    elif serpiente.direccion == "izquierda":
        serpiente.shape("assets/snakehead_left.gif")
    elif serpiente.direccion == "derecha":
        serpiente.shape("assets/snakehead_right.gif")

def mover(): #la funcion mueve 20 pixeles la serpiente dependiendo de hacia donde vaya su direccion
    actualizar_sprite_cabeza()
    if serpiente.direccion == "arriba":
        serpiente.sety(serpiente.ycor() + 20)
    elif serpiente.direccion == "abajo":
        serpiente.sety(serpiente.ycor() - 20)
    elif serpiente.direccion == "derecha":
        serpiente.setx(serpiente.xcor() + 20)
    elif serpiente.direccion == "izquierda":
        serpiente.setx(serpiente.xcor() - 20)

def ir_arriba(): #la funcion determina la direccion de la serpiennte como 'arriba' solo si dicha direccion es diferente de 'abajo'
    if serpiente.direccion != "abajo":
        serpiente.direccion = "arriba"

def ir_abajo():#la funcion determina la direccion de la serpiennte como 'abajo' solo si dicha direccion es diferente de 'arriba'
    if serpiente.direccion != "arriba":
        serpiente.direccion = "abajo"

def ir_izquierda():#la funcion determina la direccion de la serpiennte como 'izquierda' solo si dicha direccion es diferente de 'derecha'
    if serpiente.direccion != "derecha":
        serpiente.direccion = "izquierda"

def ir_derecha():#la funcion determina la direccion de la serpiennte como 'derecha' solo si dicha direccion es diferente de 'izquierda'
    if serpiente.direccion != "izquierda":
        serpiente.direccion = "derecha"

# Controles
ventana.listen() #hace que el programa "escuche" las entradas del teclado
ventana.onkeypress(ir_arriba, "w") #se ejecuta la funcion ir_arriba si se presiona la w
ventana.onkeypress(ir_abajo, "s") #se ejecuta la funcion ir_abajo si se presiona la s
ventana.onkeypress(ir_izquierda, "a") #se ejecuta la funcion ir_izquierda si se presiona la a
ventana.onkeypress(ir_derecha, "d") #se ejecuta la funcion ir_derecha si se presiona la d

segmentos = [] #lista para almacenar los segmentos del cuerpo

def actualizar_sprite_cola():  #funcion para actualizar el sprite de la cola
    if len(segmentos) == 0:
        return

    cola = segmentos[-1]
    if len(segmentos) > 1: #evalua si hay mas de un segmento y si es asi asigna el penultimo segmento a 'penultimo'
        penultimo = segmentos[-2]
    else:
        penultimo = serpiente #si no hay mas de un segmento se le asigna la serpiente a 'penultimo'

    dx = penultimo.xcor() - cola.xcor() #determina la posicion de acuerdo a la posicion de penultimo menos la cola, para asi saber su movimiento
    dy = penultimo.ycor() - cola.ycor()

    if dx == 20: #si la posicion es de 20 pixeles se mueve hacia la derecha por lo que se le asigna el sprite 'snaketail_right.gif'
        cola.shape("assets/snaketail_right.gif")
    elif dx == -20: #si la posicion es de -20 pixeles se mueve hacia la izquierda por lo que se le asigna el sprite 'snaketail_left.gif'
        cola.shape("assets/snaketail_left.gif")
    elif dy == 20: #si la posicion es de 20 pixeles se mueve hacia arriba por lo que se le asigna el sprite 'snaketail_up.gif'
        cola.shape("assets/snaketail_up.gif")
    elif dy == -20: #si la posicion es de -20 pixeles se mueve hacia abajo por lo que se le asigna el sprite 'snaketail_down.gif'
        cola.shape("assets/snaketail_down.gif")

def juego():
    global puntuacion_jugador, puntuacion_maxima, tiempo_retraso
    ventana.update() #actualiza la ventana

    # Colisión con bordes
    if abs(serpiente.xcor()) > 300 or abs(serpiente.ycor()) > 220: #se mide si la cabeza de la serpiente supero los limites de la pantalla, para esto se usa su posicion x,y en valor absoluto y se mide con la mitad de la resolucion de pantalla
        gm.mixer.music.pause() #en caso de haber colisionado se detiene la musica de fondo
        sonido_colision.play() #se reproduce el sonido de colision
        turtle.time.sleep(1) #se hace una pausa de un segundo para dar a entender al usuario que ha perdido
        gm.mixer.music.unpause() #se inicia nuevamente la musica de fondo
        serpiente.goto(0, 0) #la serpiente es llevada al centro de la pantalla (la posicion 0,0)
        serpiente.direccion = "Stop" #la direccion de movimiento de la serpiente es puesta nuevamente en 'stop' para que asi no haya movimiento
        serpiente.shape("assets/snakehead_up.gif") #se pone el sprite de 'snakehead_up.gif' para resetear la orientacion de la serpiente
        for segmento in segmentos:
            segmento.goto(1000, 1000) #todos los segmentos anadidos se mueven hacia una posicion lejana a la visible por la pantalla
        segmentos.clear() #los segmentos tras la serpiente son eliminados
        guardar_puntuaciones(puntuacion_jugador, puntuacion_maxima) #Se llama la función para guardar la puntuación
        mostrar_tabla_final() #Se llama la función para mostrar la tabla de puntuaciones
        return # Salir de la función juego para no seguir el bucle
    
        

    # Comer
    if serpiente.distance(comida) < 20: #se evalua si la serpiente esta a menos de 20 pixeles de el item comida'
        x = random.randint(-300//20, 300//20) * 20 #se genera una posicion random en el eje x teniendo en cuenta las resoluciones usadas para el juego
        y = random.randint(-220//20, 220//20) * 20 #se genera una posicion random en el eje y teniendo en cuenta las resoluciones usadas para el juego
        comida.goto(x, y) #se mueve al item 'comida' a las posiciones generadas anteriormente

        nuevo_segmento = turtle.Turtle() #se genera un nuevo segmento
        nuevo_segmento.speed(0) #dicho segmento se le agrega velocidad 0
        nuevo_segmento.shape("assets/snakebody.gif") #se le agrega el sprite de 'snakebody.gif' a dicho segmento
        nuevo_segmento.penup()
        segmentos.append(nuevo_segmento) #el segmento es anadido a la lista de segmentos

        puntuacion_jugador += 5 #se le suma 5 a la puntuacion actual del jugador
        if puntuacion_jugador > puntuacion_maxima: #se evalua si la puntuacion actual del jugador es mayor que la puntuacion maxima registrada
            puntuacion_maxima = puntuacion_jugador #en caso de ser asi se remplaza

        pluma.clear()
        pluma.write(f"Puntuación: {puntuacion_jugador}  Puntuación más alta: {puntuacion_maxima}", align="center", font=("Arial", 24, "normal")) #se actualiza el letrero de puntuacion

    # Mover segmentos
    for i in range(len(segmentos) - 1, 0, -1): #mueve los segmentos a la posicion del segmento anterior
        x = segmentos[i - 1].xcor()
        y = segmentos[i - 1].ycor()
        segmentos[i].goto(x, y)

    if len(segmentos) > 0: #mueve el primer segmento a la posicion de la serpiente
        segmentos[0].goto(serpiente.xcor(), serpiente.ycor())

    # Cuerpo siempre usa misma imagen
    for i in range(len(segmentos)):
        segmentos[i].shape("assets/snakebody.gif")

    # Cola con dirección
    actualizar_sprite_cola()

    mover()

    # Colisión con cuerpo
    for segmento in segmentos:
        if segmento.distance(serpiente) < 20: #evalua si algun segmento esta a menos de 20px de la serpiente, si es asi colisionaron
            gm.mixer.music.pause()
            sonido_colision.play()
            turtle.time.sleep(1)
            gm.mixer.music.unpause()
            serpiente.goto(0, 0)
            serpiente.direccion = "Stop"
            serpiente.shape("assets/snakehead_up.gif")
            
            guardar_puntuaciones(puntuacion_jugador, puntuacion_maxima) #Se llama la función para guardar la puntuación
            mostrar_tabla_final() #Se llama la función para mostrar la tabla de puntuaciones
            return # Salir de la función juego para no seguir el bucle
 
    ventana.ontimer(juego, int(tiempo_retraso * 1000))

#Llamar la función para iniciar la pantalla de carga antes de comenzar el juego
mostrar_pantalla_carga()
ventana.bgpic("assets/background.gif")

# Iniciar juego
juego()
ventana.mainloop()
