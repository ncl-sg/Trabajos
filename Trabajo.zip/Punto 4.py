f = input("Ingrese una frase: ")
p = ""
for c in range(len(f)):
    if f[c] != " ":
        p += f[c]
    else:
        if p:
            print(p)
        p = ""
if p:
    print(p)