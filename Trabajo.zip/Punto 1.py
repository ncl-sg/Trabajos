n = int(input("Digite el número: "))
b = int(input("Digite una base >= 2 y < 10: "))
g = ""
if 2 <= b < 10:
    if n == 0:
        g = "0"
    else:
        while n > 0:
            r = str(n % b)
            n = n // b
            g = r + g
    print(f"El número en base {b} es: {g}")
else:
    print("Base inválida")