print('''Las operaciones disponibles son:
      suma, resta, multiplicacion, division.
      O si deseas salir.''')
o= input("Elija una operacion: ")
x= 1
while x == 1:
    if o == "suma" or o == "Suma":
        n= int(input("Digite el primer valor: "))
        m= int(input("Digite el segundo valor: "))
        r= n + m
        print(f"El resultado de la operacion es: {r}")
        o= input("Elija una operacion: ")
    elif o == "resta" or o == "Resta":
        n= int(input("Digite el primer valor: "))
        m= int(input("Digite el segundo valor: "))
        r= n - m
        print(f"El resultado de la operacion es: {r}")
        o= input("Elija una operacion: ")
    elif o == "multiplicacion" or o == "Multiplicacion":
        n= int(input("Digite el primer valor: "))
        m= int(input("Digite el segundo valor: "))
        r= n * m
        print(f"El resultado de la operacion es: {r}")
        o= input("Elija una operacion: ")
    elif o == "division" or o == "Division":
        n= int(input("Digite el primer valor: "))
        m= int(input("Digite el segundo valor: "))
        r= n // m
        print(f"El resultado de la operacion es: {r}")
        o= input("Elija una operacion: ")
    elif o == "salir" or o == "Salir":
        print("Fin del programa")
        x = x + 1
    else:
        print("Opcion invalida")
        o= input("Elija una operacion: ")