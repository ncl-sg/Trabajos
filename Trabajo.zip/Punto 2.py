a= int(input('''Digite el valor maximo hasta el cual quiera hacer la lista de numeros
             (solo se escribiran los que sean divisibles por 2, 3 o 5): '''))
for i in range(a + 1):
    if i % 2 == 0 or i % 3 == 0 or i % 5 == 0:
        print(i)