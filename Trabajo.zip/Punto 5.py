p = input("Ingrese una palabra: ")
v = 'aeiou'
if p[0] in v:
    p = p + 'way'
else:
    i = 0
    n = False
    while i < len(p) and not n:
        if p[i] in v:
            p = p[i:] + p[:i] + 'ay'
            n = True
        i += 1
    else:
        if not n:
            p = p + 'ay'
print("La palabra en Pig Latin es: " + p)